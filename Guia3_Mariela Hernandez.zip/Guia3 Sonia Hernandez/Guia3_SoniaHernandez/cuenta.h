#ifndef CUENTA_H_INCLUDED
#define CUENTA_H_INCLUDED
#include <iostream>
#include <string>
#include "abono.h"
#include "cliente.h"
using namespace std;
class cuenta
{
private:
    int numcuenta;
    cliente *cli;
    abono *lstabono[28];
    float saldo;
    int contabono;
public:
    cuenta();
    cuenta(int,cliente*);
    int getnumcuenta();
    void setnumcuenta(int);
    cliente *getcliente();
    void setcliente(cliente*);
    bool agregarabono(abono*);
    abono **getlstabono();
    float getsaldo();
    int getcontabono();
    ~cuenta();
};
#endif // CUENTA_H_INCLUDED
