#ifndef ABONO_H_INCLUDED
#define ABONO_H_INCLUDED
#include <iostream>
#include <string>
#include "fecha.h"
using namespace std;
class abono
{
private:
    fecha *fabono;
    float montoabono;
public:
    abono(fecha*,float);
    fecha *getfecha();
    float getmontoabono();
    ~abono();
};

#endif // ABONO_H_INCLUDED
