#include <iostream>
#include <string>
#include "cuenta.h"
#define TAM 5
using namespace std;
cuenta::cuenta(){
    this->numcuenta=0;
    this->saldo=0;
    this->contabono=0;
}
cuenta::cuenta(int ncuenta, cliente *C){
    this->numcuenta=ncuenta;
    this->cli=C;
    this->saldo=0;
    this->contabono=0;
}
int cuenta::getnumcuenta(){
    return this->numcuenta;
}
void cuenta::setnumcuenta(int ncuenta){
    this->numcuenta=ncuenta;
}
cliente* cuenta::getcliente(){
    return this->cli;
}
void cuenta::setcliente(cliente *C){
    this->cli=C;
}
bool cuenta::agregarabono(abono *Ab){
    if (this->contabono<TAM){
        this->lstabono[this->contabono]=Ab;
        this->saldo+=Ab->getmontoabono();
        contabono++;
        return true;
    }else{
        return false;
    }

}
abono** cuenta::getlstabono(){
    return this->lstabono;
}
float cuenta::getsaldo(){
    return this->saldo;
}
int cuenta::getcontabono(){
    return this->contabono;
}
