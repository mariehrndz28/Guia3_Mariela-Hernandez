#ifndef CLIENTE_H_INCLUDED
#define CLIENTE_H_INCLUDED
#include <iostream>
#include <string>
using namespace std;
class cliente
{
private:
    int id;
    string nom;
    string ape;
public:
    cliente(int, string, string);
    int getid();
    string getnombre();
    string getapellido();
    ~cliente();
};

#endif // CLIENTE_H_INCLUDED
