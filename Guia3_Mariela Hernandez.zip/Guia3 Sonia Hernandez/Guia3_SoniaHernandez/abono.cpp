#include <iostream>
#include <string>
#include "abono.h"
using namespace std;
abono::abono(fecha *fA, float mA){
    this->fabono=fA;
    this->montoabono=mA;
}
fecha* abono::getfecha(){
    return this->fabono;
}
float abono::getmontoabono(){
    return this->montoabono;
}
abono::~abono(){

}
