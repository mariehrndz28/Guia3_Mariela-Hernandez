#include <iostream>
#include <string.h>
#include "cuenta.h"
using namespace std;

int menu(){
    int op;
    cout<<"menu\n";
    cout<<"1. agregar cliente a la lista\n";
    cout<<"2. agregar cuenta a la lista\n";
    cout<<"3. hacer abonos\n";
    cout<<"4. mostrar lista de clientes\n";
    cout<<"5. mostrar lista de cuentas\n";
    cout<<"6. mostrar detalles de la cuenta\n";
    cout<<"7. salir\n";
    cout<<"digite la opcion: ";cin>>op;
    return op;
}
cliente *agregarcliente() {
    cliente *cli;
    int id;
    string n, a;
    cout << "digite el codigo del cliente: ";cin >> id;
    cout << "digite el nombre del cliente: ";cin >> n;
    cout << "digite el apellido del cliente: ";cin >> a;
    cli = new cliente(id, n, a);
    return cli;
}

cliente *buscarcliente(cliente *lstcli[], int contcli, int codcli) {
    bool encontrado = false;
    int contador = 0;
    cliente *cli = NULL;
    while (contador < contcli && !encontrado) {
        if (lstcli[contador]->getid() == codcli) {
            encontrado = true;
            cli = lstcli[contador];
        } else {
            contador++;
        }
    }
    return cli;
}
cuenta *registrarcuenta(cliente *cli) {
    int nc;
    cuenta *cta;
    cout<<"digite el numero de la cuenta"<<endl;
    cin>>nc;
    cta = new cuenta(nc,cli);
    return cta;
}
cuenta *buscarcuenta(cuenta *lstcuenta[], int cont, int nc) {
    bool encontrado = false;
    int contador = 0;
    cuenta *cta = NULL;
    while (contador < cont && !encontrado) {
        if (lstcuenta[contador]->getnumcuenta() == nc) {
            encontrado = true;
            cta = lstcuenta[contador];
        } else {
            contador++;
        }
    }
    return cta;
}
void hacerabono(cuenta *cta) {
    int d,m,a;
    fecha *fa;
    float ma;
    abono *ab;
    cout<<"digite la fecha del abono"<<endl;
    cout<<"dia: ";cin>>d;
    cout<<"mes: ";cin>>m;
    cout<<"anio: ";cin>>a;
    cout<<"digite el monto del abono:"<<endl;
    cin>>ma;
    fa = new fecha(d,m,a);
    ab = new abono(fa, ma);
    cta->agregarabono(ab);
}
void detalles(cuenta *cta) {
    cout << "numero de cuenta: " << cta->getnumcuenta() << endl;
    cout << "cliente: " << cta->getcliente()->getnombre() << " " << cta->getcliente()->getapellido() << endl;
    cout << "saldo: " << cta->getsaldo() << endl;
    cout<<"abonos realizados"<<endl;
    if (cta->getcontabono() == 0) {
        cout << "No hay abonos" << endl;
    } else {
        cout << "No\tfecha\tMonto" << endl;
        abono **lst = cta->getlstabono();
        for (int i = 0; i < cta->getcontabono(); i++) {
            cout << (i + 1) << "\t";
            lst[i]->getfecha()->mostrarfecha();
            cout << "\t" << lst[i]->getmontoabono() << endl;
        }
    }
}
int main()
{
    cliente *lstcli[28];
    cuenta *lstcuenta[28];
    int opc, contcli = 0, contcuenta = 0, idcli, idcta;
    cliente *cli= NULL;
    cuenta *cta = NULL;
    do {
        system("cls");
        opc = menu();
        switch (opc) {
        case 1:
            if (contcli < 28) {
                lstcli[contcli] = agregarcliente();
                contcli++;
                cout << "cliente agregado correctamente" << endl;
            } else {
                cout << "La lista de clientes est� llena" << endl;
            }
            break;
        case 2:
            if (contcuenta < 28) {
                cout<<"Digite el id del cliente:"<<endl;
                cin>>idcli;
                cli= buscarcliente(lstcli, contcli, idcli);
                if(cli){
                    lstcuenta[contcuenta] = registrarcuenta(cli);
                    contcuenta++;
                    cout<<"la cuenta se agrego con exito"<<endl;
                }
                else{
                    cout<<"el cliente no se encontro"<<endl;
                }
            }
            break;

        case 3:
            cout<<"Digite el numero de la cuenta"<<endl;
            cin>>idcta;
            cta = buscarcuenta(lstcuenta, contcuenta, idcta);

                if(cta){
                    hacerabono(cta);
                    cout<<"el abono se agrego con exito"<<endl;
                }
                else{
                    cout<<"la cuenta no se encontro"<<endl;
                }

            break;

        case 4:
            if(contcli == 0)
                cout<<"la lista esta vacia"<<endl;
            else{
                cout<<"id\tNombre\tApellido"<<endl;
                for(int i=0;i<contcli;i++){
                    cout<< lstcli[i]->getid()<<"\t";
                    cout<< lstcli[i]->getnombre()<<"\t";
                    cout<< lstcli[i]->getapellido()<<endl;
                }
            }
            break;

        case 5:
                if(contcuenta == 0){
                    cout<<"La lista es vacia"<<endl;
                }else{
                    cout<<"No\tCliente\tSaldo"<<endl;
                    for(int i=0; i<contcuenta; i++){
                        cout<< lstcuenta[i]->getnumcuenta()<<"\t";
                        cout<< lstcuenta[i]->getcliente()->getnombre()<<" "<< lstcuenta[i]->getcliente()->getapellido() <<"\t";
                        cout<< lstcuenta[i]->getsaldo()<<endl;
                    }
                }
            break;

        case 6:
            cout<<"digite el numero de la cuenta"<<endl;
            cin>>idcta;

            cta = buscarcuenta(lstcuenta, contcuenta, idcta);
            if(cta){
                detalles(cta);
            }else{
                cout<<"la cuenta no se encontro"<<endl;
            }
            break;

        case 7:
            cout << "saliendo del programa..." << endl;
            break;

        default:
            cout << "opcion invalida." << endl;
            break;

        }

        system("pause");
    } while (opc != 7);
    return 0;
}
