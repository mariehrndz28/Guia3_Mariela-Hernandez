#include <iostream>
#include <string>
#include "fecha.h"
using namespace std;
fecha::fecha(int d, int m, int a){
    this->dia=d;
    this->mes=m;
    this->anio=a;
}
void fecha::mostrarfecha(){
    cout<<this->dia<<"/";
    cout<<this->mes<<"/";
    cout<<this->anio;
}
fecha::~fecha(){

}
