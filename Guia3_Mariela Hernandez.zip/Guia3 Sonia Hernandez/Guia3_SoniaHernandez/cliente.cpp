#include <iostream>
#include <string>
#include "cliente.h"
using namespace std;
cliente::cliente(int cod, string n, string a){
    this->id=cod;
    this->nom=n;
    this->ape=a;
}
int cliente::getid(){
    return this->id;
}
string cliente::getnombre(){
    return this->nom;
}
string cliente::getapellido(){
    return this->ape;
}
cliente::~cliente(){

}
