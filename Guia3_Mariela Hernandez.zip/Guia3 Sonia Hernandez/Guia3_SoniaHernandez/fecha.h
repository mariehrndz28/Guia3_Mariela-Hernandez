#ifndef FECHA_H_INCLUDED
#define FECHA_H_INCLUDED
#include <iostream>
#include <string>
using namespace std;
class fecha
{
private:
    int dia;
    int mes;
    int anio;
public:
    fecha(int,int,int);
    ~fecha();
    void mostrarfecha();
};

#endif // FECHA_H_INCLUDED
